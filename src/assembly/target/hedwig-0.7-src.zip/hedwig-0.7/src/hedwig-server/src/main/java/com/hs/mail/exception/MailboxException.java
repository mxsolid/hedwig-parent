package com.hs.mail.exception;

/**
 * 
 * @author Wonchul, Doh
 * @since Dec 23, 2016
 *
 */
public class MailboxException extends Exception {

	private static final long serialVersionUID = -7026340522404114564L;

	public MailboxException(String message) {
		super(message);
	}

}
