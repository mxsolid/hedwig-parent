SFTP

https://sourceforge.net/p/forge/documentation/SFTP/

HOST sftp://frs.sourceforge.net
USER wonchul,hwmail
PASS same as SVN
PORT 22