package com.hs.mail.webmail.util.text;


public interface Processor {

	String process(String type, String text);

}
