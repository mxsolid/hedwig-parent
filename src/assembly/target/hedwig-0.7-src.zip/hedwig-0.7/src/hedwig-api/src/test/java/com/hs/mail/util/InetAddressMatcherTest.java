package com.hs.mail.util;

import org.junit.Test;

public class InetAddressMatcherTest {

	@Test
	public void test() throws Exception {
		System.out.println(InetAddressMatcher.getCidrSignature());
	}

}
