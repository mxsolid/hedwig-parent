package com.hs.mail.imap.dao;


public class MySqlACLDao extends AnsiACLDao {
}
