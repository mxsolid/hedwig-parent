package com.hs.mail.imap.dao;

import javax.sql.DataSource;

public interface DaoSupport {

	void setDataSource(DataSource dataSource);

}
