package com.hs.mail.imap.dao;


public class OracleACLDao extends AnsiACLDao {
}
